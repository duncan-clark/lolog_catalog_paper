#ifndef CTriple_H
#define CTriple_H

#include <Rcpp.h>

#include <lolog.h>
#include <Rcpp.h>
#include <vector>

namespace lologext{

using namespace Rcpp;
using namespace std;


/**
* An example lolog statistic, defined as the number of nodes
* with degree greater than or equal to "degree"
*/
template<class Engine>
class CTriple : public lolog::BaseStat< Engine > {
public:
  int degree; //the minimum degree
  
  //Constructor
  CTriple(){
    std::vector<double> v(1,0.0);
    this->stats=v;
  }
  
  //Parse parameters
  CTriple(List params){
    std::vector<double> v(1,0.0);
    this->stats=v;
  }
  
  
  //The name 
  virtual string name(){return "cTriple";}
  
  std::vector<std::string> statNames(){
    std::vector<std::string> statnames(1,"cTriple");
    return statnames;
  }
  
  //Define shared neighbours function - taken from original LOLOG package
  int sharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    if(net.isDirected()){
      return directedSharedNbrs(net, from, to);
    }
    return undirectedSharedNbrs(net, from, to);
  }
  
  //
  
  int undirectedSharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
    NeighborIterator fit = net.begin(from);
    NeighborIterator fend = net.end(from);
    NeighborIterator tit = net.begin(to);
    NeighborIterator tend = net.end(to);
    int shared = 0;
    while(tit!=tend && fit!=fend){
      if(*tit==*fit){
        shared++;
        tit++;
        fit++;
      }else if(*tit<*fit){
        tit++;
      }else
        fit++;
    }
    return shared;
  }
  
  //Type 1 shared neighbours e.g. cycles
  
  int directedSharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
    NeighborIterator fit, fend, tit, tend;
    
    int sn = 0;
    fit = net.inBegin(from);
    fend = net.inEnd(from);
    tit = net.outBegin(to);
    tend = net.outEnd(to);
    while(fit != fend && tit != tend){
      if(*tit == *fit){
        sn++;
        tit++;
        fit++;
      }else if(*tit < *fit)
        tit++;
      else
        fit++;
    }
    return sn;
  }
  
  //Calculate the statistic
  virtual void calculate(const lolog::BinaryNet<Engine>& net){
    std::vector<double> v(1,0);
    this->stats=v;
    this->lastStats = std::vector<double>(1,0.0);
    if(this->thetas.size()!=1)
      this->thetas = v;
    for(int i=0;i<net.size();i++){
      for(int j=0; j<net.size(); j++){
        if(net.hasEdge(i,j)){
          int tmp = sharedNbrs(net,i,j);
          this->stats[0] += tmp;
        }
      }
    }
    if(net.isDirected()){this->stats[0] = this->stats[0]/3.0;}else{
      this->stats[0] = this->stats[0]/6.0; 
    };
  }
  
  //Update the statistic given a dyad toggle
  virtual void dyadUpdate(const lolog::BinaryNet<Engine>& net,const int &from,const int &to,const std::vector<int> &order,const int &actorIndex){
    lolog::BaseOffset<Engine>::resetLastStats();
    if(!net.hasEdge(from,to)){
      this->stats[0] += sharedNbrs(net,from,to);
    }else{
      this->stats[0] -= sharedNbrs(net,from,to);
    }
  }
  
  //Declare that this statistic is order independent
  bool isOrderIndependent(){
    return true;
  }
  
  //Declare that this statistic is dyad independent
  bool isDyadIndependent(){
    return false;
  }
  
};

typedef lolog::Stat<lolog::Undirected, CTriple<lolog::Undirected> > UndirectedCTriple;
typedef lolog::Stat<lolog::Directed, CTriple<lolog::Directed> > DirectedCTriple;



}



void registerCTriple();

#endif
