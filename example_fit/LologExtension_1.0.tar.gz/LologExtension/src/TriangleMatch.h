#ifndef TriangleMatch_H
#define TriangleMatch_H

#include <Rcpp.h>

#include <lolog.h>
#include <Rcpp.h>
#include <vector>

namespace lologext{
  
using namespace Rcpp;
using namespace std;


/**
  * Matching triangles LOLOG statistics
*/
template<class Engine>
class TriangleMatch : public lolog::BaseStat<Engine>{
protected:
  typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
  std::string variableName; /*!< the name of the matching variable */
  int varIndex; /*!< the index of the variable in the network */
  int nstats; /*!< the number of stats generated (i.e. the number of levels squared) */
  int nlevels; /*!< the number of levels of the variable */
public:
  
  
  TriangleMatch(){
    variableName="";
    nstats=nlevels=varIndex = -1;
    std::vector<double> v(1,0.0);
    std::vector<double> t(1,0.0);
    this->stats=v;
    this->thetas = t;
  }
  TriangleMatch(std::string name){
    variableName=name;
    nstats=nlevels=varIndex = -1;
    std::vector<double> v(1,0.0);
    std::vector<double> t(1,0.0);
    this->stats=v;
    this->thetas = t;
  }
  TriangleMatch(List params){
    variableName="";
    nstats=nlevels=varIndex = -1;
    std::vector<double> v(1,0.0);
    std::vector<double> t(1,0.0);
    this->stats=v;
    this->thetas = t;
  }
  
  std::string name(){
    return "TriangleMatch";
  }
  
  std::vector<std::string> statNames(){
    std::vector<std::string> statnames(1,"TriangleMatch"+variableName);
    return statnames;
  }
  
  int sharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    if(net.isDirected()){
      return directedSharedNbrs(net, from, to);
    }
    return undirectedSharedNbrs(net, from, to);
  }
  int undirectedSharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    NeighborIterator fit = net.begin(from);
    NeighborIterator fend = net.end(from);
    NeighborIterator tit = net.begin(to);
    NeighborIterator tend = net.end(to);
    
    int value1, value2, value3;
    int varIndex;
    
    // Get the variable index
    std::vector<std::string> vars = net.discreteVarNames();
    int variableIndex = -1;
    for(int i=0;i<vars.size();i++){
      if(vars[i] == variableName){
        std::cout<< vars[i];
        variableIndex = i;
      }
    }
    if(variableIndex<0){
      std::cout<< variableName;
      std::cout<< variableIndex;
      ::Rf_error("TriangleMatch::calculate nodal attribute not found in network");
    }
    varIndex = variableIndex;
    
    value1 = net.discreteVariableValue(varIndex,from) - 1;
    value2 = net.discreteVariableValue(varIndex,to) - 1;
    
    if(value1 != value2){
      return 0;
    }
    
    int shared = 0;
    while(tit!=tend && fit!=fend){
      if(*tit==*fit){
        value3 =  net.discreteVariableValue(varIndex,*tit) - 1;
        if(value3 == value1){
          shared++;
        }
        tit++;
        fit++;
      }else if(*tit<*fit){
        tit++;
      }else
        fit++;
    }
    return shared;
  }
  
  int directedSharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    NeighborIterator ifit = net.inBegin(from);
    NeighborIterator ifend = net.inEnd(from);
    NeighborIterator ofit = net.outBegin(from);
    NeighborIterator ofend = net.outEnd(from);
    
    // Make sure all three nodes have the same values
    int value1, value2, value3;
    int varIndex;
    
    // Get the variable index
    std::vector<std::string> vars = net.discreteVarNames();
    int variableIndex = -1;
    for(int i=0;i<vars.size();i++){
      if(vars[i] == variableName){
        std::cout<< vars[i];
        variableIndex = i;
      }
    }
    if(variableIndex<0){
      std::cout<< variableName;
      std::cout<< variableIndex;
      ::Rf_error("TriangleMatch::calculate nodal attribute not found in network");
    }
    varIndex = variableIndex;
    
    value1 = net.discreteVariableValue(varIndex,from) - 1;
    value2 = net.discreteVariableValue(varIndex,to) - 1;
    
    if(value1 != value2){
      return 0;
    }
    
    
    
    int shared = 0;
    while(ifit != ifend){
      value3 =  net.discreteVariableValue(varIndex,*ifit) - 1;
      if(value1 == value3){
        shared += net.hasEdge(*ifit, to);
        shared += net.hasEdge(to, *ifit);
      }
      ifit++;
    }
    while(ofit != ofend){
      value3 =  net.discreteVariableValue(varIndex,*ofit) - 1;
      if(value1 == value3){
        shared += net.hasEdge(*ofit, to);
        shared += net.hasEdge(to, *ofit);
      }
      ofit++;
    }
    return shared;
  }
  
  
  void calculate(const lolog::BinaryNet<Engine>& net){
    this->initSingle(0.0);
    double sumTri = 0.0;
    
    boost::shared_ptr<std::vector< std::pair<int,int> > > edges = net.edgelist();
    
    std::vector< std::pair<int,int> >::iterator it = edges->begin();
    while(it != edges->end()){
      int shared = sharedNbrs(net, (*it).first,(*it).second);
      sumTri += shared;
      it++;
    }
    sumTri = sumTri/3.0;
    this->stats[0] = sumTri;//sumSqrtTri - sumSqrtExpected;
  }
  
  
  void dyadUpdate(const lolog::BinaryNet<Engine>& net,const int &from,const int &to,const std::vector<int> &order,const int &actorIndex){
    lolog::BaseOffset<Engine>::resetLastStats();
    int shared = sharedNbrs(net, from, to);
    bool hasEdge = net.hasEdge(from,to);
    if(hasEdge){
      lolog::BaseOffset<Engine>::update(-shared,0);
      //sumTri -= shared;
    }else{
      lolog::BaseOffset<Engine>::update(shared,0);
      //sumTri += shared;
    }
    //this->stats[0] = sumTri;//sumSqrtTri - sumSqrtExpected;
  }
  
  bool isOrderIndependent(){
    return true;
  }
};
  
typedef lolog::Stat<lolog::Undirected, TriangleMatch<lolog::Undirected> > UndirectedTriangleMatch;
typedef lolog::Stat<lolog::Directed, TriangleMatch<lolog::Directed> > DirectedTriangleMatch;
  
}



void registerTriangleMatch();

#endif
