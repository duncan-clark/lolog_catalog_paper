// [[Rcpp::depends(lolog)]]
#include "TriangleMatch.h"
#include <lolog.h>


//[[Rcpp::export()]]
void registerTriangleMatch(){
  Rcpp::XPtr< lolog::AbstractStat<lolog::Directed> > ps1(new lologext::DirectedTriangleMatch());
  REGISTER_DIRECTED_STATISTIC(ps1);
  Rcpp::XPtr< lolog::AbstractStat<lolog::Undirected> > ps2(new lologext::UndirectedTriangleMatch());
  REGISTER_UNDIRECTED_STATISTIC(ps2);
}
