// [[Rcpp::depends(lolog)]]
#include "TTriple.h"
#include <lolog.h>


//[[Rcpp::export()]]
void registerTTriple(){
  Rcpp::XPtr< lolog::AbstractStat<lolog::Directed> > ps1(new lologext::DirectedTTriple());
  REGISTER_DIRECTED_STATISTIC(ps1);
  Rcpp::XPtr< lolog::AbstractStat<lolog::Undirected> > ps2(new lologext::UndirectedTTriple());
  REGISTER_UNDIRECTED_STATISTIC(ps2);
}
