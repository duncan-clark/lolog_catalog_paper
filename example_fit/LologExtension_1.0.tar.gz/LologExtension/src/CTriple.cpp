// [[Rcpp::depends(lolog)]]
#include "CTriple.h"
#include <lolog.h>


//[[Rcpp::export()]]
void registerCTriple(){
  Rcpp::XPtr< lolog::AbstractStat<lolog::Directed> > ps1(new lologext::DirectedCTriple());
  REGISTER_DIRECTED_STATISTIC(ps1);
  Rcpp::XPtr< lolog::AbstractStat<lolog::Undirected> > ps2(new lologext::UndirectedCTriple());
  REGISTER_UNDIRECTED_STATISTIC(ps2);
  
}
