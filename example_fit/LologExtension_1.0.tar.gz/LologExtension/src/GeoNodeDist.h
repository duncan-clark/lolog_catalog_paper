#ifndef GeoNodeDist_H
#define GeoNodeDist_H

#include <Rcpp.h>

#include <lolog.h>
#include <Rcpp.h>
#include <vector>

namespace lologext{

using namespace Rcpp;
using namespace std;

//Define the geodesicDistance function first which calculates the geodesic distance between to nodes

//Define the geodesic distance functions
template<class Engine>
int undirectedGeodesicDistance(const lolog::BinaryNet<Engine>& net, int from, int to){
  typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
  int dist = 1;
  std::vector<int> nodes(1,from);
  std::vector<int> nodes_visited(1,from);
  std::vector<int> nodes_new;
  while(dist != 0){
    nodes_new.clear();
    for(std::vector<int>::iterator n = nodes.begin();n<nodes.end(); n++){
      for(NeighborIterator fit = net.begin(*n); fit < net.end(*n); fit++){
        if(*fit == to){
          return dist;
        }else{
          if(std::find(nodes_visited.begin(),nodes_visited.end(),*fit) == nodes_visited.end()){
            nodes_new.push_back(*fit);
            nodes_visited.push_back(*fit);
          }
        }
      }
    }
    if(nodes_new.size() != 0){
      dist += 1;
      nodes = nodes_new;
    }else{
      return 0;
    }
  }
}

template<class Engine>
int directedGeodesicDistance(const lolog::BinaryNet<Engine>& net, int from, int to){
  typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
  int dist = 1;
  std::vector<int> nodes(1,from);
  std::vector<int> nodes_visited(1,from);
  std::vector<int> nodes_new;
  while(dist != 0){
    nodes_new.clear();
    for(std::vector<int>::iterator n = nodes.begin();n<nodes.end(); n++){
      for(NeighborIterator fit = net.outBegin(*n); fit < net.outEnd(*n); fit++){
        if(*fit == to){
          return dist;
        }else{
          if(std::find(nodes_visited.begin(),nodes_visited.end(),*fit) == nodes_visited.end()){
            nodes_new.push_back(*fit);
            nodes_visited.push_back(*fit);
          }
        }
      }
    }
    if(nodes_new.size() != 0){
      dist += 1;
      nodes = nodes_new;
    }else{
      return 0;
    }
  }
}

/*!
 * Counts the geodesic deistance between 2 nodes
 */
template<class Engine>
int geodesicDistance(const lolog::BinaryNet<Engine>& net, int from, int to){
  if(net.isDirected()){
    return directedGeodesicDistance(net, from, to);
  }
  return undirectedGeodesicDistance(net, from, to);
}

/**
* Calcualte the number of geodesics between nodes of length k,One stat for each user-generated value.
*/
// Based on the ESP term code, just replacing shared neighbours between i and j with the geodesic distance between i and  j.
// Left the type parameter in though it is not needed
template<class Engine>
class GeoNodeDist : public lolog::BaseStat< Engine > {
protected:
  // typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
  std::vector<int> dists;
  int type;
  
public:
  
  GeoNodeDist(){
    type = 2;
  }
  
  virtual ~GeoNodeDist(){}; //stick with vcalculate?
  
  GeoNodeDist(std::vector<int> dists1){
    dists = dists1;
    type = 2;
  }
  
  
  /*!
  * \param params 	a list of length 1, the first element of which is an integer vector of geodesic distances
  */
  
  GeoNodeDist(List params){
    lolog::ParamParser p(name(), params);
    dists = p.parseNext< std::vector<int> >("d");
    type = p.parseNext("type", 2);
    if(type < 1 || type > 4)
      ::Rf_error("GeoNodeDist: type must be 1,2,3, or 4");
    p.end();
  }
  
  std::string name(){
    return "GeoNodeDist";
  }
  
  
  std::vector<std::string> statNames(){
    std::vector<std::string> statnames;
    for(int i=0;i<dists.size();i++){
      int e = dists[i];
      std::string nm = "dist."+lolog::asString(e);
      if(type != 2)
        nm = lolog::asString(type) + "-" + nm;
      statnames.push_back(nm);
    }
    return statnames;
  }
  
  virtual void calculate(const lolog::BinaryNet<Engine>& net){
    int nstats = dists.size();
    this->init(nstats);
    
    //boost::shared_ptr< std::vector<std::pair<int,int> > > el = net.edgelist();
    
    for(int from = 0; from < (net.size()-1); from++){
      for(int to = (from+1); to < net.size(); to++){
        int disti = geodesicDistance(net, from, to);
        for(int j=0;j<nstats;j++){
          this->stats[j] += disti==dists[j];
        }
      }
    }
  }
  
  void dyadUpdate(const lolog::BinaryNet<Engine>& net,const int &from,const int &to,const std::vector<int> &order,const int &actorIndex){
    lolog::BaseOffset<Engine>::resetLastStats();
    
    lolog::BinaryNet<Engine>* pnet = const_cast< lolog::BinaryNet<Engine>* > (&net);
    pnet->toggle(from,to);
    int nstats = dists.size();
    this->init(nstats);
    
    boost::shared_ptr< std::vector<std::pair<int,int> > > el = pnet->edgelist();
    
    for(int i=0;i<el->size();i++){
      int ifrom = el->at(i).first;
      int ito = el->at(i).second;
      int disti = geodesicDistance(net, ifrom, ito);
      for(int j=0;j<nstats;j++){
        this->stats[j] += disti==dists[j];
      }
    }
  }
  
  bool isOrderIndependent(){
    return true;
  }
  
};

typedef lolog::Stat<lolog::Directed, GeoNodeDist<lolog::Directed> > DirectedGeoNodeDist;
typedef lolog::Stat<lolog::Undirected, GeoNodeDist<lolog::Undirected> > UndirectedGeoNodeDist;

}



void registerGeoNodeDist();

#endif
