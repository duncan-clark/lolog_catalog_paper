#ifndef _ErnmExtension_LOLOG_HELLO_WORLD_H
#define _ErnmExtension_LOLOG_HELLO_WORLD_H

#include <Rcpp.h>


Rcpp::List lolog_hello_world() ;

#endif
