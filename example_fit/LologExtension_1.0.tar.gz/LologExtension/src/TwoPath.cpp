// [[Rcpp::depends(lolog)]]
#include "TwoPath.h"
#include <lolog.h>


//[[Rcpp::export()]]
void registerTwoPath(){
  Rcpp::XPtr< lolog::AbstractStat<lolog::Directed> > ps1(new lologext::DirectedTwoPath());
  REGISTER_DIRECTED_STATISTIC(ps1);
  Rcpp::XPtr< lolog::AbstractStat<lolog::Undirected> > ps2(new lologext::UndirectedTwoPath());
  REGISTER_UNDIRECTED_STATISTIC(ps2);
  
}
