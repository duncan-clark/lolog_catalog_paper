#ifndef TwoPath_H
#define TwoPath_H

#include <Rcpp.h>

#include <lolog.h>
#include <Rcpp.h>
#include <vector>

namespace lologext{

using namespace Rcpp;
using namespace std;


/**
* An example lolog statistic, defined as the number of nodes
* with degree greater than or equal to "degree"
*/
template<class Engine>
class TwoPath : public lolog::BaseStat< Engine > {
public:
  int degree; //the minimum degree
  
  //Constructor
  TwoPath(){
    std::vector<double> v(1,0.0);
    this->stats=v;
  }
  
  //Parse parameters
  TwoPath(List params){
    std::vector<double> v(1,0.0);
    this->stats=v;
  }
  
  
  //The name 
  virtual string name(){return "twoPath";}
  
  std::vector<std::string> statNames(){
    std::vector<std::string> statnames(1,"twoPath");
    return statnames;
  }
  
  //Define shared neighbours function - taken from original LOLOG package
  int sharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    if(net.isDirected()){
      return directedSharedNbrs(net, from, to);
    }
    return undirectedSharedNbrs(net, from, to);
  }
  
  //
  
  int undirectedSharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
    NeighborIterator fit = net.begin(from);
    NeighborIterator fend = net.end(from);
    NeighborIterator tit = net.begin(to);
    NeighborIterator tend = net.end(to);
    int shared = 0;
    while(tit!=tend && fit!=fend){
      if(*tit==*fit){
        shared++;
        tit++;
        fit++;
      }else if(*tit<*fit){
        tit++;
      }else
        fit++;
    }
    return shared;
  }
  
  //Type 1 shared neighbours e.g. cycles
  
  int directedSharedNbrs(const lolog::BinaryNet<Engine>& net, int from, int to){
    typedef typename lolog::BinaryNet<Engine>::NeighborIterator NeighborIterator;
    NeighborIterator fit, fend, tit, tend;
    
    int sn = 0;
    fit = net.inBegin(from);
    fend = net.inEnd(from);
    tit = net.outBegin(to);
    tend = net.outEnd(to);
    while(fit != fend && tit != tend){
      if(*tit == *fit){
        sn++;
        tit++;
        fit++;
      }else if(*tit < *fit)
        tit++;
      else
        fit++;
    }
    return sn;
  }
  
  //Calculate the statistic
  virtual void calculate(const lolog::BinaryNet<Engine>& net){
    std::vector<double> v(1,0);
    this->stats=v;
    this->lastStats = std::vector<double>(1,0.0);
    if(this->thetas.size()!=1)
      this->thetas = v;
    for(int i=0;i<net.size();i++){
      for(int j=0; j<net.size(); j++){
        int tmp = sharedNbrs(net,i,j);
        this->stats[0] += tmp;
      }
    }
  }
  
  //Update the statistic given a dyad toggle
  virtual void dyadUpdate(const lolog::BinaryNet<Engine>& net,const int &from,const int &to,const std::vector<int> &order,const int &actorIndex){
    lolog::BaseOffset<Engine>::resetLastStats();
    std::vector<double> v(1,0);
    this->stats=v;
    int deg = 0;
    if(net.isDirected()){
      deg += net.outdegree(to);
      }else{
        deg += net.degree(to);
    }
    if(!net.hasEdge(from,to)){
      this->stats[0] += deg;
    }else{if(!net.isDirected()){deg -= 1;} 
      /* since the network has the edge to toggle removes 1 from degree for undirected but does
       * not effect outdegree of to */
      this->stats[0] -= deg;
    }
  }
  
  //Declare that this statistic is order independent
  bool isOrderIndependent(){
    return true;
  }
  
  //Declare that this statistic is dyad independent
  bool isDyadIndependent(){
    return false;
  }
  
};

typedef lolog::Stat<lolog::Undirected, TwoPath<lolog::Undirected> > UndirectedTwoPath;
typedef lolog::Stat<lolog::Directed, TwoPath<lolog::Directed> > DirectedTwoPath;



}



void registerTwoPath();

#endif
